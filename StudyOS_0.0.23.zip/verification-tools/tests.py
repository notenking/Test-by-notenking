from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time,base64,traceback
OUT=Path('/workspace/studyos/evidence');RESULT=[]
URL='http://localhost:8765/release/StudyOS_0.0.23.html'
def check(name,fn):
 try:
  detail=fn(); RESULT.append({'test':name,'status':'PASS','detail':detail});print('PASS',name,flush=True)
 except Exception as e:
  RESULT.append({'test':name,'status':'FAIL','detail':str(e),'trace':traceback.format_exc()});print('FAIL',name,str(e)[:300],flush=True)
def verify(v,m='assertion failed'):
 assert v,m
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 def fresh(url=URL):
  c=b.new_context(viewport={'width':1440,'height':1000},accept_downloads=True);g=c.new_page();g.goto(url);g.wait_for_timeout(200);return c,g
 def task(g,title='Biology · Cell division',scope='day'):
  g.evaluate('(scope)=>newTask({scope})',scope);g.locator('#task-title').fill(title);g.locator('[data-action="save-task"]').click();g.wait_for_timeout(120)
 def read(g):return g.evaluate('JSON.parse(localStorage.getItem(KEY))')
 def edit_complete_delete():
  c,g=fresh();task(g);verify(len(read(g)['tasks'])==1)
  g.locator('.task-title').first.click();g.locator('#task-title').fill('Biology · Recall the stages');g.locator('[data-action="save-task"]').click();verify(read(g)['tasks'][0]['title']=='Biology · Recall the stages')
  g.locator('[data-action="toggle-task"]').first.click();verify(read(g)['tasks'][0]['done']);g.locator('#toast button').click();verify(not read(g)['tasks'][0]['done'])
  g.locator('.task-title').first.click();g.locator('[data-action="delete-task"]').click();g.get_by_role('button',name='Delete',exact=True).click();verify(len(read(g)['tasks'])==0);g.locator('#toast button').click();verify(len(read(g)['tasks'])==1)
  g.reload();verify(len(read(g)['tasks'])==1);c.close();return 'UI create, edit, complete/undo, delete/undo, refresh'
 check('Task lifecycle and undo',edit_complete_delete)
 def invalid():
  c,g=fresh();g.evaluate('newTask()');g.locator('[data-action="save-task"]').click();verify(g.locator('#task-title').get_attribute('aria-invalid')=='true');g.locator('#task-title').fill('Invalid estimate');g.locator('[name="minutes"]').fill('-2');g.locator('[data-action="save-task"]').click();verify(g.locator('#task-form').is_visible());verify(not read(g) or len(read(g)['tasks'])==0);g.keyboard.press('Escape');c.close();return 'Empty title and negative estimate rejected; editor retained'
 check('Input validation',invalid)
 def corruption():
  c,g=fresh();g.evaluate('localStorage.setItem(KEY,"{broken")');g.reload();verify(g.locator('.recovery-banner').is_visible());msg=g.evaluate('()=>{try{commitState(baseState());return "BAD"}catch(e){return e.message}}');verify(msg!='BAD');verify(g.evaluate('localStorage.getItem(KEY)')=='{broken')
  with g.expect_download() as d:g.locator('[data-action="export-data"]').first.click()
  path=OUT/'recovery-test.json';d.value.save_as(path);data=json.loads(path.read_text());verify(data['rawSnapshot']=='{broken')
  g.evaluate('()=>commitState(baseState(),{recover:true})');verify(g.evaluate('Object.keys(localStorage).some(k=>k.startsWith(KEY+".recovery.")&&localStorage.getItem(k)==="{broken")'));c.close();return 'Raw bytes exported and preserved in recovery key before explicit restoration'
 check('Corrupt snapshot protection and raw export',corruption)
 def concurrency():
  c,g=fresh();task(g);g.locator('.task-title').first.click();other=c.new_page();other.goto(URL);other.locator('[data-action="toggle-task"]').first.click();g.locator('#task-title').fill('Draft after other tab completion');g.locator('[data-action="save-task"]').click();verify(read(g)['tasks'][0]['done']);verify(g.locator('#task-error').is_visible());verify(g.locator('#task-title').input_value().startswith('Draft'))
  other.evaluate('()=>{const n=structuredClone(state);n.tasks=[];commitState(n)}');g.locator('[data-action="save-task"]').click();verify(len(read(g)['tasks'])==0);c.close();return 'Two actual tabs: completed and deleted task cannot be overwritten/resurrected; draft retained'
 check('Two-tab edit conflicts',concurrency)
 def timer_real():
  c,g=fresh();g.evaluate('go("focus")');g.locator('[data-action="start-timer"]').click();g.wait_for_timeout(2200);g.locator('[data-action="pause-timer"]').click();g.wait_for_function('state.timer.status==="paused"');elapsed=read(g)['timer']['elapsed'];verify(elapsed>=1800);g.wait_for_timeout(1200);verify(read(g)['timer']['elapsed']==elapsed);g.reload();verify(read(g)['timer']['status']=='paused');g.evaluate('go("focus")');g.locator('[data-action="start-timer"]').click();g.wait_for_timeout(1200);g.locator('[data-action="finish-timer"]').click();g.locator('#feedback-form button[type="submit"]').click();g.wait_for_function('state.sessions.length===1');verify(len(read(g)['sessions'])==1);g.reload();verify(len(read(g)['sessions'])==1);c.close();return f'Real wall-clock waits 4.6s total; pause elapsed {elapsed}ms; resume, finish, save and reload persisted'
 check('Real timer pause/resume/save/reload',timer_real)
 def timer_notebook():
  outcomes={}
  for version in ['0.0.22','0.0.23']:
   c,g=fresh('http://localhost:8765/'+('original' if version=='0.0.22' else 'release')+'/StudyOS_'+version+'.html');g.evaluate('go("notebook")');g.wait_for_timeout(100);g.get_by_role('button',name='Add entry',exact=True).click();g.get_by_placeholder('Optional — uses a question summary when saved').fill('Unsaved notebook work')
   g.evaluate('()=>{state.timer={id:"isolated",method:"pomodoro",phase:"focus",status:"running",duration:1000,elapsed:0,started:Date.now()-2000,taskId:""};commitState(state)}');g.evaluate('finishTimer(false)');g.wait_for_timeout(100)
   outcomes[version]={'screen':g.evaluate('screen'),'preserved':g.get_by_placeholder('Optional — uses a question summary when saved').count()>0}
   c.close()
  verify(not outcomes['0.0.22']['preserved']);verify(outcomes['0.0.23']['preserved']);return {'controlled_expiry':outcomes,'note':'Expired timestamp fixture, not a real one-minute wait'}
 check('Timer expiry preserves inline notebook editor',timer_notebook)
 def backup_timer():
  c,g=fresh();r=g.evaluate('''async()=>{const s=baseState(),exp=Date.now()-3*86400000;s.timer={id:'old',method:'pomodoro',phase:'focus',status:'running',duration:1800000,elapsed:0,started:exp-60000,taskId:''};await importFile(new File([JSON.stringify({app:'StudyOS',version:'0.0.4',exportedAt:new Date(exp).toISOString(),data:s})],'old.json'));return modal.importData.state.timer}''');verify(r['status']=='paused');verify(abs(r['elapsed']-60000)<20);g.locator('[data-action="v4-confirm-import"]').click();verify(read(g)['timer']['status']=='paused');g.reload();verify(read(g)['timer']['elapsed']==r['elapsed']);c.close();return 'Three-day-old running backup restored paused at 60s, not 30-minute expiry; controlled timestamps'
 check('Old running backup restore semantics',backup_timer)
 def calendar():
  c,g=fresh();g.evaluate('go("plan")');verify(g.locator('[role="grid"] [role="row"]').count()==6);verify(g.locator('[role="gridcell"][tabindex="0"]').count()==1);cell=g.locator('[role="gridcell"][tabindex="0"]');day=cell.get_attribute('data-date');cell.focus();g.keyboard.press('ArrowRight');verify(g.evaluate('document.activeElement.dataset.date')!=day);g.keyboard.press('Home');verify(g.evaluate('(new Date(document.activeElement.dataset.date+"T12:00:00")).getDay()')==1);g.keyboard.press('End');verify(g.evaluate('(new Date(document.activeElement.dataset.date+"T12:00:00")).getDay()')==0);g.keyboard.press('ArrowDown');g.keyboard.press('Space');verify(g.evaluate('document.activeElement.getAttribute("role")')=='gridcell');c.close();return 'Six semantic rows; one roving cell; Arrow/Home/End/Space preserve selected-cell focus'
 check('Planner keyboard navigation',calendar)
 def notebook_backup():
  c,g=fresh();g.evaluate('go("notebook")');g.wait_for_timeout(100);g.get_by_role('button',name='Add entry',exact=True).click();g.get_by_placeholder('Optional — uses a question summary when saved').fill('Test microscopy note');g.get_by_placeholder('Paste a question, add a page reference or attach an image…').fill('Identify the phases of mitosis.')
  png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j2ioAAAAASUVORK5CYII=')
  g.locator('#notebook-root input[type="file"]').set_input_files({'name':'fixture.png','mimeType':'image/png','buffer':png});g.wait_for_timeout(300);g.get_by_role('button',name='Save entry',exact=True).click();g.wait_for_timeout(250)
  initial=g.evaluate('StudyNotebook.backup()');verify(bool(initial));
  with g.expect_download() as d:g.evaluate('exportData()')
  f=OUT/'roundtrip-backup.json';d.value.save_as(f);backup=json.loads(f.read_text());verify(backup['notebook']['records']==initial['records'])
  c2,h=fresh();h.evaluate('(text)=>importFile(new File([text],"backup.json"))',f.read_text());h.locator('[data-action="v4-confirm-import"]').click();h.wait_for_timeout(300);restored=h.evaluate('StudyNotebook.backup()');verify(restored['records']==initial['records'],'notebook records differ');h.reload();verify(h.evaluate('StudyNotebook.backup()')['records']==initial['records']);(OUT/'notebook-shape.json').write_text(json.dumps(initial,indent=2));c.close();c2.close();return 'UI entry with PNG; full backup export/import into fresh browser context; IndexedDB roundtrip exact, reload retained'
 check('Notebook text and image backup roundtrip',notebook_backup)
 def legacy():
  c,g=fresh();result=g.evaluate('''()=>{let s=baseState();s.customFuture={retained:true};s.assessments={future:'keep'};s.tasks=[{id:'parent',title:'Year goal',scope:'year',start:'2026-01-01',due:'2026-12-31',custom:'yes'},{id:'child',title:'Day work',scope:'day',start:'2026-10-17',due:'2026-10-17',parentId:'parent',links:['https://example.com']}];const v=validateState(s);return {custom:v.customFuture,tasks:v.tasks,assessments:v.assessments,keys:OLDKEYS}}''');verify(result['custom']['retained']);verify(result['tasks'][1]['parentId']=='parent');verify(result['tasks'][0]['custom']=='yes');verify(result['tasks'][1]['links']==['https://example.com']);c.close();return result
 check('Legacy schema and unknown-field compatibility',legacy)
 def layout():
  c,g=fresh();errors=[];g.on('pageerror',lambda e:errors.append(str(e)));layouts=[]
  for density in ['empty','populated']:
   if density=='populated':
    g.evaluate('go("today")');task(g,'Biology · Recall cell division');task(g,'Mathematics · Practice integration');task(g,'History · Draft essay outline');task(g,'Finish the biology revision unit','week');g.evaluate('()=>{let n=structuredClone(state);n.sessions.push({id:"fixture-session",date:today(),minutes:25,phase:"focus",method:"pomodoro",taskId:n.tasks[0].id,note:"Isolated screenshot fixture",at:new Date().toISOString()});commitState(n)}')
   for width in [1280,1440,1920]:
    g.set_viewport_size({'width':width,'height':1080})
    for route in ['today','plan','focus','reflection','notebook']:
     g.evaluate('(r)=>go(r)',route);g.wait_for_timeout(150);g.screenshot(path=str(OUT/f'{density}-{route}-{width}.png'),full_page=True)
     overflow=g.evaluate('document.documentElement.scrollWidth>innerWidth');verify(not overflow,f'{density} {route} {width} horizontal overflow');layouts.append(f'{density}/{route}/{width}')
  (OUT/'fixture-state.json').write_text(json.dumps(read(g),indent=2));verify(not errors,str(errors));c.close();return {'screenshots':layouts,'pageErrors':errors}
 check('Core pages: three widths, empty and populated',layout)
 b.close()
(OUT/'test-results.json').write_text(json.dumps(RESULT,indent=2,ensure_ascii=False));print('RESULT',len(RESULT),sum(x['status']=='FAIL' for x in RESULT),flush=True)
