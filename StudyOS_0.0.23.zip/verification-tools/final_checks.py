from playwright.sync_api import sync_playwright
from pathlib import Path
import json
R=[];O=Path('/workspace/studyos/evidence')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for v in ['0.0.22','0.0.23']:
  c=b.new_context();g=c.new_page();g.goto('http://localhost:8765/'+('original' if v=='0.0.22' else 'release')+'/StudyOS_'+v+'.html')
  result=g.evaluate('''async()=>{const s=baseState(),exp=Date.now()-3*86400000;s.timer={id:'old',method:'pomodoro',phase:'focus',status:'running',duration:1800000,elapsed:0,started:exp-60000,taskId:''};await importFile(new File([JSON.stringify({app:'StudyOS',version:'0.0.4',exportedAt:new Date(exp).toISOString(),data:s})],'old.json'));return {status:modal.importData.state.timer.status,elapsed:timerElapsed(modal.importData.state.timer)}}''');R.append({'test':'Old running backup browser comparison '+v,'result':result});c.close()
 c=b.new_context();g=c.new_page();g.goto('http://localhost:8765/release/StudyOS_0.0.23.html')
 g.evaluate('()=>{commitState(baseState());go("notebook")}');g.wait_for_timeout(100);g.get_by_role('button',name='Add entry',exact=True).click();g.get_by_placeholder('Optional — uses a question summary when saved').fill('Notebook regression');g.get_by_role('button',name='Save entry',exact=True).click();g.wait_for_timeout(150)
 g.evaluate('()=>{state.settings.notebook="here";commitState(state);render()}');g.wait_for_timeout(100);g.get_by_role('button',name='Edit',exact=True).click();g.get_by_placeholder('Optional — uses a question summary when saved').fill('Edited notebook regression');g.get_by_role('button',name='Save changes',exact=True).click();g.wait_for_timeout(150);assert g.evaluate('StudyNotebook.backup()')['records'][0]['title']=='Edited notebook regression';g.reload();assert g.evaluate('StudyNotebook.backup()')['records'][0]['title']=='Edited notebook regression';R.append({'test':'Notebook edit and reload','status':'PASS'})
 before=g.evaluate('localStorage.getItem(KEY)');g.evaluate('importFile(new File(["{bad"],"invalid.json"))');assert g.evaluate('localStorage.getItem(KEY)')==before;R.append({'test':'Malformed backup leaves storage unchanged','status':'PASS'})
 result=g.evaluate('''()=>{const before=localStorage.getItem(KEY),fn=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k===KEY)throw new DOMException('Quota exceeded','QuotaExceededError');return fn.call(this,k,v)};let message;try{commitState({...state,custom:'failed'})}catch(e){message=e.message}finally{Storage.prototype.setItem=fn}return{preserved:localStorage.getItem(KEY)===before,message}}''');assert result['preserved'] and result['message'];R.append({'test':'Simulated quota failure preserves snapshot','status':'PASS','detail':result})
 with g.expect_download() as d:
  g.evaluate('()=>{state.timer={id:"export",phase:"focus",status:"running",method:"timeblock",duration:1800000,elapsed:10000,started:Date.now()-2000};commitState(state);return exportData()}')
 d.value.save_as(O/'running-export-test.json');snapshot=json.loads((O/'running-export-test.json').read_text())['data']['timer'];assert snapshot['status']=='paused' and 12000<=snapshot['elapsed']<14000;R.append({'test':'Running timer exported as paused snapshot','status':'PASS','detail':snapshot})
 c.close();b.close()
(O/'final-test-results.json').write_text(json.dumps(R,indent=2));print(json.dumps(R,indent=2))
