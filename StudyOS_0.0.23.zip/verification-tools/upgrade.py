from pathlib import Path
src=Path('/workspace/studyos/original/StudyOS_0.0.22.html').read_text()
def replace(a,b):
 global src
 assert a in src,a[:90]
 src=src.replace(a,b,1)
replace('let storageError = false;', '''// 0.0.23: unreadable snapshots are read-only until an explicit restore.
let storageError = false;
let unreadableSnapshot = null;''')
replace('if (key === KEY) break;', '''if (key === KEY) {
        try { unreadableSnapshot = localStorage.getItem(KEY); } catch (_) { unreadableSnapshot = ''; }
        break;
      }''')
replace('function commitState(next) {\n  if (!demo) {', '''function commitState(next, { recover = false } = {}) {
  if (!demo) {
    if (unreadableSnapshot === null && !recover) {
      let currentRaw = null;
      try {
        currentRaw = localStorage.getItem(KEY);
        if (currentRaw) JSON.parse(currentRaw);
      } catch (_) {
        unreadableSnapshot = currentRaw || '';
        storageError = true;
      }
    }
    if (unreadableSnapshot !== null && !recover)
      throw Error("Your saved data could not be read. It is protected from changes. Download the original snapshot, then restore a valid backup in Settings.");
    if (unreadableSnapshot !== null && recover) {
      // Do not replace the damaged snapshot unless a second durable copy succeeds.
      localStorage.setItem(KEY + '.recovery.' + Date.now(), unreadableSnapshot);
    }''')
replace('localStorage.setItem(KEY, JSON.stringify(next));\n      storageError = false;', 'localStorage.setItem(KEY, JSON.stringify(next));\n      unreadableSnapshot = null;\n      storageError = false;')
replace('if (type === "task") {\n    const slot', '''if (type === "task") {
    modal.savedTaskBaseline = completionSignature(state.tasks.find(t => t.id === modal.task.id));
    const slot''')
replace('if (!StudyForms.validate(form)) return;\n    const t', '''if (!StudyForms.validate(form)) return;
    if (!demo && modal.task.id) {
      const savedValue = localStorage.getItem(KEY);
      const current = savedValue ? JSON.parse(savedValue) : state;
      const savedTask = current.tasks?.find(t => t.id === modal.task.id) || null;
      if (completionSignature(savedTask) !== modal.savedTaskBaseline)
        throw Error("This task changed in another tab. Your draft is kept. Close this editor and reopen the task to review the latest progress before saving.");
    }
    latestState();
    const t''')
replace('''      if (
        !manual &&
        modal &&
        !["feedback", "timer-conflict", "method-conflict"].includes(modal.type)
      ) {''','''      if (!manual) {
        updateClock();''')
replace('''      render();
      toast("Break finished. Start when you are ready.");''','''      if (manual || (screen === 'focus' && !modal)) render();
      else updateClock();
      toast("Break finished. Start when you are ready.");''')
replace('''    const notebook = await StudyNotebook.backup();
    const data = {''','''    const notebook = await StudyNotebook.backup();
    if (unreadableSnapshot !== null) {
      download(new Blob([JSON.stringify({app:"StudyOS recovery", exportedAt:new Date().toISOString(), key:KEY, rawSnapshot:unreadableSnapshot, notebook}, null, 2)], {type:"application/json"}), 'StudyOS-original-recovery.json');
      toast("Original unreadable snapshot and notebook exported. Keep this file before restoring a valid backup.");
      return;
    }
    const snapshot = structuredClone(state);
    if (snapshot.timer?.status === 'running') {
      snapshot.timer.elapsed = timerElapsed(state.timer);
      snapshot.timer.status = 'paused';
      snapshot.timer.started = Date.now();
    }
    const data = {''')
replace('''      data: state,
      notebook,''','''      data: snapshot,
      notebook,''')
replace('''      next = validateState(raw);
    openModal("v4-import",''','''      next = validateState(raw);
    if (next.timer?.status === 'running') {
      const exported = Date.parse(raw.exportedAt);
      const elapsed = Number(next.timer.elapsed) || 0;
      const captured = Number.isFinite(exported) ? Math.max(0, exported - next.timer.started) : 0;
      next.timer.elapsed = Math.min(next.timer.flow ? 86400000 : next.timer.duration, elapsed + captured);
      next.timer.status = 'paused';
      next.timer.started = Date.now();
    }
    openModal("v4-import",''')
replace('commitV4(imported.state);','commitState(imported.state, { recover: true });')
replace('''StudyCopy.format("ui_v4.restore_plans_and_records_current_23f621",''',''''<p class="notice">Restored timers are paused at the backup time. Resume when ready. Restoring replaces your current plan; notebook resources are merged.</p>' + StudyCopy.format("ui_v4.restore_plans_and_records_current_23f621",''')
replace('''${typeof taskDraftNotice==='function'?taskDraftNotice():''}${body}''','''${unreadableSnapshot !== null ? '<section class="recovery-banner" role="alert"><strong>Your saved data needs recovery</strong><p>The original snapshot is protected. Download it before restoring a valid backup in Settings.</p><button class="btn small" data-action="export-data">Download original snapshot</button><button class="btn small" data-action="nav" data-screen="settings">Open Settings</button></section>' : ''}${typeof taskDraftNotice==='function'?taskDraftNotice():''}${body}''')
replace('Saved locally\'} · 0.0.22','Saved locally\'} · 0.0.23')
replace("['reflection','Review','nav-review']];", "['reflection','Review','nav-review'],['notebook','Notebook','book']];")
replace("const extra = ['notebook','profile','blocking','assessment','guide'].includes(screen);", "const extra = ['profile','blocking','assessment','guide'].includes(screen);")
replace('<nav class="global-nav" aria-label="Main navigation">','<div class="workspace-label">PERSONAL WORKSPACE</div><nav class="global-nav" aria-label="Main navigation">')
replace('<div class="global-tools">','<div class="workspace-local"><span class="dot"></span> Offline workspace</div><div class="global-tools">')
replace('  for (const t of s.tasks) {\n    const p = s.tasks.find((x) => x.id === t.parentId);', '  const taskIndex = new Map(s.tasks.map(t => [t.id, t]));\n  for (const t of s.tasks) {\n    const p = taskIndex.get(t.parentId);')
replace('role="gridcell" tabindex="0"', 'role="gridcell" tabindex="${date === (cells.includes(selectedDate) ? selectedDate : cells[0]) ? 0 : -1}"')
replace('${cells\n    .map((date) => {', '${cells\n    .map((date, cellIndex) => {')
replace('return `<div class="day-cell', 'return `${cellIndex % 7 === 0 ? \'<div class="calendar-row" role="row">\' : \'\'}<div class="day-cell')
replace('more</span>` : ""}</div>`;', 'more</span>` : ""}</div>${cellIndex % 7 === 6 ? "</div>" : ""}`;')
replace('  if (ev.key === "Enter" && ev.target.matches(\'[role="gridcell"]\')) {\n    ev.preventDefault();\n    selectedDate = ev.target.dataset.date;\n    render();\n    return;\n  }', '  if (ev.target.matches(\'[role="gridcell"]\') && [\'ArrowLeft\',\'ArrowRight\',\'ArrowUp\',\'ArrowDown\',\'Home\',\'End\',\'Enter\',\' \'].includes(ev.key)) {\n    ev.preventDefault();\n    const date = ev.target.dataset.date;\n    const weekday = (E.parseDate(date).getDay() + 6) % 7;\n    const offset = {ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7,Home:-weekday,End:6-weekday}[ev.key] || 0;\n    selectedDate = E.addDays(date, offset);\n    if (selectedDate.slice(0,7) !== anchor.slice(0,7)) anchor = selectedDate;\n    render();\n    document.querySelector(`[role="gridcell"][data-date="${selectedDate}"]`)?.focus({preventScroll:true});\n    return;\n  }')
replace('        `Delete “${t.title}”${desc.length ? ` and ${desc.length} child plans` : ""}? This cannot be undone.`,\n        () => {\n          const ids = new Set([id, ...desc.map((x) => x.id)]);\n          state.tasks = state.tasks.filter((t) => !ids.has(t.id));\n          saveRender();\n        },','        `Delete “${t.title}”${desc.length ? ` and ${desc.length} child plans` : ""}? You can undo immediately after deletion.`,\n        () => {\n          latestState();\n          const ids = new Set([id, ...E.descendants(id, state.tasks).map(x => x.id)]);\n          const removed = state.tasks.filter(t => ids.has(t.id)).map(t => structuredClone(t));\n          const next = structuredClone(state);\n          next.tasks = next.tasks.filter(t => !ids.has(t.id));\n          commitState(next); render();\n          toast(\'Task deleted.\', {label:\'Undo\', run:() => {\n            latestState();\n            if (removed.some(t => state.tasks.some(x => x.id === t.id))) {\n              toast(\'A task with the same ID already exists. Nothing was overwritten.\'); return;\n            }\n            if (removed.some(t => t.parentId && !ids.has(t.parentId) && !state.tasks.some(x => x.id === t.parentId))) {\n              toast(\'The parent goal was removed. Restore your backup to recover this hierarchy.\'); return;\n            }\n            const restored = structuredClone(state);\n            restored.tasks.push(...removed);\n            commitState(restored); render(); toast(\'Deletion undone.\');\n          }});\n        },')
replace('toast("The timer finished. Your input is preserved. Save the session from Focus when ready.");','toast("The timer finished. Your input is preserved. Save the session when ready.", { label:"Open Focus", run:()=>go("focus") });')
css=Path('/workspace/studyos/design.css').read_text()
replace('</head>', '<style id="studyos-023-design">\n'+css+'\n</style></head>')
Path('/workspace/studyos/release/StudyOS_0.0.23.html').write_text(src)
print('wrote',len(src))
