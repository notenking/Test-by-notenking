from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time,traceback
O=Path('/workspace/studyos/evidence');R=[]
def test(n,f):
 try:R.append({'test':n,'status':'PASS','detail':f()});print('PASS',n,flush=True)
 except Exception as e:R.append({'test':n,'status':'FAIL','detail':str(e),'trace':traceback.format_exc()});print('FAIL',n,str(e)[:200],flush=True)
def ok(v,m='Assertion failed'):assert v,m
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 def new(url='http://localhost:8765/release/StudyOS_0.0.23.html'):
  c=b.new_context(viewport={'width':1440,'height':1080});g=c.new_page();g.goto(url);g.wait_for_timeout(150);return c,g
 def migration():
  c,g=new();r=g.evaluate('()=>{const s=baseState();s.customFuture={keep:42};s.tasks=[{id:"legacy",title:"Legacy item",scope:"day",start:today(),due:today(),minutes:20}];localStorage.setItem(OLDKEYS[0],JSON.stringify(s));return OLDKEYS[0]}');g.reload();ok(g.evaluate('state.tasks[0].id')=='legacy');ok(g.evaluate('state.customFuture.keep')==42);ok(g.evaluate('(localStorage.getItem(KEY))')==None);g.evaluate('commitState(state)');ok(g.evaluate('JSON.parse(localStorage.getItem(KEY)).tasks[0].id')=='legacy');c.close();return 'Reload from '+r+' retained original old key and unknown fields; first save wrote same current key'
 test('Old storage key migration',migration)
 def keyboard():
  c,g=new();g.keyboard.press('Control+k');g.wait_for_timeout(100);ok(g.locator('#commands-dialog').count()>0 or g.get_by_role('dialog').count()>0,'command dialog not found');g.keyboard.press('Escape');g.evaluate('newTask()');g.wait_for_timeout(100);g.keyboard.press('Tab');ok(g.evaluate('!!document.activeElement.closest("#modal-root")'));g.keyboard.press('Escape');ok(g.locator('#task-form').count()==0);g.locator('[data-action="toggle-more"]').first.click();ok(g.locator('#more-menu').is_visible());g.keyboard.press('Escape');ok(not g.locator('#more-menu').is_visible());c.close();return 'Command palette shortcut, modal Tab focus, Escape dismissal and More disclosure'
 test('Keyboard and modal focus',keyboard)
 def fileoffline():
  c,g=new('file:///workspace/studyos/release/StudyOS_0.0.23.html');requests=[];g.on('request',lambda r:requests.append(r.url));g.evaluate('newTask()');g.locator('#task-title').fill('Offline file test');g.locator('[data-action="save-task"]').click();g.wait_for_timeout(120);g.reload();ok(g.evaluate('state.tasks.some(t=>t.title==="Offline file test")'));ok(not [u for u in requests if u.startswith('http')]);c.close();return 'Chromium file:// launch, create, local save and reload; no HTTP asset requests. User computer/Safari not verified.'
 test('Local single HTML offline smoke',fileoffline)
 def consistency():
  c,g=new();g.evaluate('newTask({scope:"week"})');g.locator('#task-title').fill('Weekly study target');g.locator('[data-action="save-task"]').click();g.wait_for_timeout(100)
  g.evaluate('newTask({parentId:state.tasks[0].id})');g.locator('#task-title').fill('Child study session');g.locator('[data-action="save-task"]').click();g.wait_for_timeout(100);g.evaluate('toggleTask(state.tasks.find(t=>t.scope==="day").id)');g.wait_for_timeout(100)
  today=g.locator('.atelier-goal').first.inner_text();g.evaluate('go("plan")');plan=g.locator('.atelier-goal').first.inner_text();ok('1 of 1 complete' in today and '1 of 1 complete' in plan);c.close();return 'Parent-child task completion reports 1 of 1 in both Today and Planner'
 test('Cross-page goal consistency',consistency)
 def perf():
  result={}
  for ver in ['0.0.22','0.0.23']:
   c,g=new('http://localhost:8765/'+('original' if ver=='0.0.22' else 'release')+'/StudyOS_'+ver+'.html')
   result[ver]=g.evaluate('''()=>{const out=[];for(const count of [5000,10000]){const s=baseState();s.tasks=Array.from({length:count},(_,i)=>{const date=E.addDays('2020-01-01',i%2400);return{id:'task-'+i,title:'Study chapter '+i,scope:'day',start:date,due:date,minutes:30,parentId:''}});let a=performance.now();const v=validateState(s);let validation=performance.now()-a;state=v;a=performance.now();screen='plan';anchor='2026-07-01';selectedDate=anchor;render();out.push({count,validationMs:Math.round(validation),renderMs:Math.round(performance.now()-a)});}return out}''');c.close()
  return result
 test('Browser performance: multi-year 5k and 10k records',perf)
 def screenshots():
  c,g=new();fixture=json.loads((O/'fixture-state.json').read_text());g.evaluate('(s)=>{commitState(validateState(s));render()}',fixture)
  backup=json.loads((O/'roundtrip-backup.json').read_text());g.evaluate('(s)=>StudyNotebook.restore(s)',backup['notebook'])
  g.evaluate('()=>{state.settings.notebook="here";state.timer={id:"screenshot-paused",phase:"focus",status:"paused",method:"timeblock",duration:1800000,elapsed:300000,started:Date.now(),taskId:state.tasks[0].id};commitState(state)}')
  for width in [1280,1440,1920]:
   g.set_viewport_size({'width':width,'height':1080})
   for route in ['today','plan','focus','reflection','notebook']:
    g.evaluate('(r)=>go(r)',route);g.wait_for_timeout(200);g.evaluate('document.getElementById("toast").classList.remove("show")');g.screenshot(path=str(O/f'populated-{route}-{width}.png'),full_page=True)
    ok(g.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  for route in ['profile','assessment','blocking','guide','settings']:
   g.set_viewport_size({'width':1440,'height':1080});g.evaluate('(r)=>go(r)',route);g.wait_for_timeout(120);g.screenshot(path=str(O/f'after-{route}.png'),full_page=True)
  g.evaluate('go("notebook")');g.wait_for_timeout(120);g.get_by_role('button',name='Add entry',exact=True).click();g.get_by_placeholder('Optional — uses a question summary when saved').fill('An unsaved entry');g.screenshot(path=str(O/'after-notebook-editor.png'),full_page=True)
  c.close();return '15 populated core screenshots include actual PNG notebook entry and paused timer; all five secondary pages and notebook editor captured'
 test('Final populated screenshots and secondary routes',screenshots)
 b.close()
(O/'extra-test-results.json').write_text(json.dumps(R,indent=2,ensure_ascii=False))
