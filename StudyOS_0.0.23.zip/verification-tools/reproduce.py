from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']); c=b.new_context();page=c.new_page()
 page.goto('http://localhost:8765/original/StudyOS_0.0.22.html');page.evaluate('localStorage.setItem("studyos.beta.0.0.4","{broken")');page.reload()
 print('corrupt before',page.evaluate('localStorage.getItem(KEY)'))
 print('write attempt',page.evaluate('()=>{try{commitState(structuredClone(state));return "saved"}catch(e){return e.message}}'))
 print('corrupt preserved',page.evaluate('localStorage.getItem(KEY)==="{broken"'))
 page.evaluate('localStorage.clear()');page.reload()
 page.evaluate('newTask()');page.locator('#task-title').fill('Original task');page.locator('[data-action="save-task"]').click()
 page.locator('[data-action="edit-task"]').first.click()
 page.evaluate('()=>{const s=JSON.parse(localStorage.getItem(KEY));s.tasks[0].done=true;s.tasks[0].status="done";s.tasks[0].remainingMinutes=0;localStorage.setItem(KEY,JSON.stringify(s))}')
 page.locator('#task-title').fill('Changed title');page.locator('[data-action="save-task"]').click()
 print('concurrent done preserved',page.evaluate('JSON.parse(localStorage.getItem(KEY)).tasks[0].done'))
 page.evaluate('()=>{screen="notebook";render()}');page.wait_for_timeout(300)
 print(page.locator('main').inner_text());print(page.locator('#notebook-root button').evaluate_all('(a)=>a.map(e=>({t:e.innerText,d:e.dataset}))'))
 b.close()
