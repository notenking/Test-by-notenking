from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1000}); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://localhost:8765/original/StudyOS_0.0.22.html');page.wait_for_timeout(500)
 out={}
 for route in ['today','plan','focus','reflection','notebook','profile','assessment','blocking','guide','settings']:
  page.locator('[data-action="nav"][data-screen="'+route+'"]').first.evaluate('(e)=>e.click()');page.wait_for_timeout(350)
  out[route]=page.locator('main').inner_text()
  page.screenshot(path=f'/workspace/studyos/evidence/before-{route}.png',full_page=True)
 page.locator('[data-action="nav"][data-screen="today"]').first.click()
 page.locator('[data-action="new-task"]').filter(visible=True).first.click()
 page.locator('#task-title').fill('Review cell division');page.locator('[data-action="save-task"]').click();page.wait_for_timeout(300)
 out['populated']=page.locator('main').inner_text();page.screenshot(path='/workspace/studyos/evidence/before-populated.png',full_page=True)
 out['storage']=page.evaluate('JSON.parse(localStorage.getItem("studyos.beta.0.0.4"))');out['errors']=errors
 open('/workspace/studyos/evidence/audit.json','w').write(json.dumps(out,indent=2))
 print(json.dumps({k:v[:400] if isinstance(v,str) else v for k,v in out.items() if k!='storage'},indent=2))
 b.close()
